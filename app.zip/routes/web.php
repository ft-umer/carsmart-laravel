<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('dashboard');
});

// Auth routes
Route::get('/sign-in', fn () => view('auth.sign-in'))->name('login');
Route::get('/forgot-password', fn () => view('auth.forgot-password'))->name('password.request');
Route::get('/reset-password/{token}', fn ($token) => view('auth.reset-password', ['token' => $token]))->name('password.reset');
Route::get('/two-factor', fn () => view('auth.two-factor'))->name('two-factor');
Route::get('/terms-consent', fn () => view('auth.terms-consent'))->name('terms.consent');
Route::get('/account-locked', fn () => view('auth.locked'))->name('account.locked');
Route::get('/session-expired', fn () => view('auth.session-expired'))->name('session.expired');