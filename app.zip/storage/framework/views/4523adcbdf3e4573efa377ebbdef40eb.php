

<?php $__env->startSection('title', 'Sign In'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .page-bg {
        background-image: url('<?php echo e(asset('assets/media/images/2600x1200/bg-10.png')); ?>');
    }
    .dark .page-bg {
        background-image: url('<?php echo e(asset('assets/media/images/2600x1200/bg-10-dark.png')); ?>');
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="flex items-center justify-center grow bg-center bg-no-repeat page-bg">
    <div class="kt-card max-w-[370px] w-full">

        <form
            action="<?php echo e(route('login')); ?>"
            method="POST"
            class="kt-card-content flex flex-col gap-5 p-10"
            id="sign_in_form"
        >
            <?php echo csrf_field(); ?>

            
            <div class="text-center mb-2.5">
                <h3 class="text-lg font-medium text-mono leading-none mb-2.5">
                    Sign in
                </h3>
            </div>

            
            <?php if($errors->any() || session('error')): ?>
                <div class="kt-alert kt-alert-danger flex items-center gap-2" role="alert">
                    <i class="ki-filled ki-shield-cross text-danger"></i>
                    <span class="text-sm">
                        <?php echo e(session('error') ?? 'We could not sign you in. Please check your details and try again.'); ?>

                    </span>
                </div>
            <?php endif; ?>

            
            <div class="flex flex-col gap-1">
                <label for="email" class="kt-form-label font-normal text-mono">
                    Email address
                </label>
                <input
                    id="email"
                    name="email"
                    type="email"
                    class="kt-input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    placeholder="email@email.com"
                    value="<?php echo e(old('email')); ?>"
                    required
                    autofocus
                    autocomplete="email"
                />
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-xs text-danger mt-0.5"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="flex flex-col gap-1">
                <div class="flex items-center justify-between gap-1">
                    <label for="password" class="kt-form-label font-normal text-mono">
                        Password
                    </label>
                    <a href="<?php echo e(route('password.request')); ?>" class="text-sm kt-link shrink-0">
                        Forgot Password?
                    </a>
                </div>

                <div class="kt-input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     data-kt-toggle-password="true">
                    <input
                        id="password"
                        name="password"
                        type="password"
                        placeholder="Enter Password"
                        required
                        autocomplete="current-password"
                    />
                    <button
                        class="kt-btn kt-btn-sm kt-btn-ghost kt-btn-icon bg-transparent! -me-1.5"
                        data-kt-toggle-password-trigger="true"
                        type="button"
                        aria-label="Toggle password visibility"
                    >
                        <span class="kt-toggle-password-active:hidden">
                            <i class="ki-filled ki-eye text-muted-foreground"></i>
                        </span>
                        <span class="hidden kt-toggle-password-active:block">
                            <i class="ki-filled ki-eye-slash text-muted-foreground"></i>
                        </span>
                    </button>
                </div>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-xs text-danger mt-0.5"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="flex flex-col gap-1">
                <span class="kt-form-label font-normal text-mono">Application</span>
                <div class="flex items-center gap-4">
                    <label class="kt-label flex items-center gap-2 cursor-pointer">
                        <input
                            class="kt-radio kt-radio-sm"
                            type="radio"
                            name="app_target"
                            value="admin"
                            <?php echo e(old('app_target', session('last_app', 'admin')) === 'admin' ? 'checked' : ''); ?>

                        />
                        <span class="text-sm text-mono">Admin</span>
                    </label>
                    <label class="kt-label flex items-center gap-2 cursor-pointer">
                        <input
                            class="kt-radio kt-radio-sm"
                            type="radio"
                            name="app_target"
                            value="crm"
                            <?php echo e(old('app_target', session('last_app', 'admin')) === 'crm' ? 'checked' : ''); ?>

                        />
                        <span class="text-sm text-mono">Customer Relationship Management</span>
                    </label>
                </div>
            </div>

            
            <label class="kt-label">
                <input
                    class="kt-checkbox kt-checkbox-sm"
                    type="checkbox"
                    name="remember"
                    value="1"
                    <?php echo e(old('remember') ? 'checked' : ''); ?>

                />
                <span class="kt-checkbox-label">Remember me</span>
            </label>

            
            <button type="submit" class="kt-btn kt-btn-primary flex justify-center grow">
                Sign In
            </button>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\carsmart_laravel\resources\views/auth/sign-in.blade.php ENDPATH**/ ?>