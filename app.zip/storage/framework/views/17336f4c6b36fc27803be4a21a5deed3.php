<!DOCTYPE html>
<html class="h-full" data-kt-theme="true" data-kt-theme-mode="light" dir="ltr" lang="en">
<head>
    <base href="<?php echo e(asset('')); ?>">
    <title>Carsmart - <?php echo $__env->yieldContent('title', 'Sign In'); ?></title>
    <meta charset="utf-8"/>
    <meta name="robots" content="follow, index"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet"/>
    <link href="<?php echo e(asset('assets/vendors/apexcharts/apexcharts.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('assets/vendors/keenicons/styles.bundle.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('assets/css/styles.css')); ?>" rel="stylesheet"/>

    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('assets/media/app/apple-touch-icon.png')); ?>"/>
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('assets/media/app/favicon-32x32.png')); ?>"/>
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/media/app/favicon-16x16.png')); ?>"/>
    <link rel="shortcut icon" href="<?php echo e(asset('assets/media/app/favicon.ico')); ?>"/>
    
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="antialiased flex h-full text-base text-foreground bg-background">

    
    <script>
        const defaultThemeMode = 'light';
        let themeMode;
        if (document.documentElement) {
            if (localStorage.getItem('kt-theme')) {
                themeMode = localStorage.getItem('kt-theme');
            } else if (document.documentElement.hasAttribute('data-kt-theme-mode')) {
                themeMode = document.documentElement.getAttribute('data-kt-theme-mode');
            } else {
                themeMode = defaultThemeMode;
            }
            if (themeMode === 'system') {
                themeMode = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
            }
            document.documentElement.classList.add(themeMode);
        }
    </script>

    <?php echo $__env->yieldContent('content'); ?>

    <script src="<?php echo e(asset('assets/js/core.bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/ktui/ktui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/apexcharts/apexcharts.min.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH D:\carsmart_laravel\resources\views/layouts/auth.blade.php ENDPATH**/ ?>