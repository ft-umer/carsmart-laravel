<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="p-6">
    <h1 class="text-2xl font-bold mb-2">
        Welcome to <?php echo e(config('app.name')); ?>

    </h1>

    <p class="text-gray-600">
        Your dashboard system is ready.
    </p>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\carsmart_laravel\resources\views/welcome.blade.php ENDPATH**/ ?>