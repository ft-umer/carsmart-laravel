

<?php
    $navigation = [
        [
            'label' => 'Dashboard',
            'children' => [
                'Overview',
                'Analytics',
                'Activity',
            ],
        ],

        [
            'label' => 'Leads',
            'children' => [
                'All Leads',
                'New Leads',
                'Qualified',
                'Archived',
            ],
        ],

        [
            'label' => 'Listings',
            'children' => [
                'All Listings',
                'Active Listings',
                'Drafts',
                'Categories',
            ],
        ],

        [
            'label' => 'Auctions',
            'children' => [
                'Live Auctions',
                'Upcoming',
                'Closed',
                'Bids',
            ],
        ],

        [
            'label' => 'Editions',
            'children' => [
                'All Editions',
                'Create Edition',
                'Schedules',
            ],
        ],

        [
            'label' => 'Vendors',
            'children' => [
                'Vendor Directory',
                'Applications',
                'Performance',
            ],
        ],

        [
            'label' => 'Customers',
            'children' => [
                'Customer List',
                'Segments',
                'Support Requests',
                'Purchase History',
            ],
        ],

        [
            'label' => 'Payments',
            'children' => [
                'Transactions',
                'Invoices',
                'Refunds',
                'Payouts',
            ],
        ],

        [
            'label' => 'Logistics',
            'children' => [
                'Shipments',
                'Tracking',
                'Warehouses',
                'Delivery Status',
            ],
        ],

        [
            'label' => 'Disputes',
            'children' => [
                'Open Cases',
                'Resolved',
                'Escalations',
            ],
        ],

        [
            'label' => 'Content Management',
            'children' => [
                'Pages',
                'Blogs',
                'Media Library',
                'SEO',
            ],
        ],

        [
            'label' => 'Automations',
            'children' => [
                'Workflows',
                'Email Automation',
                'Triggers',
                'Scheduled Tasks',
            ],
        ],

        [
            'label' => 'Reports',
            'children' => [
                'Sales Reports',
                'User Reports',
                'Auction Reports',
                'Exports',
            ],
        ],

        [
            'label' => 'Settings',
            'children' => [
                'General',
                'Users & Roles',
                'Integrations',
                'Security',
            ],
        ],

        [
            'label' => 'Notifications',
            'children' => [
                'Inbox',
                'Templates',
                'Preferences',
            ],
        ],

        [
            'label' => 'Tasks',
            'children' => [
                'My Tasks',
                'Team Tasks',
                'Completed',
            ],
        ],
    ];
?>

<aside class="w-72 h-screen fixed left-0 top-0 bg-white border-r overflow-y-auto">

    
    <div class="p-5 border-b">
        <h2 class="text-xl font-bold">Admin Panel</h2>
    </div>

    
    <nav class="p-4 space-y-2">

        <?php $__currentLoopData = $navigation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="border rounded-lg overflow-hidden">

                
                <button
                    class="w-full flex items-center justify-between px-4 py-3 bg-gray-100 hover:bg-gray-200 transition"
                    type="button"
                >
                    <span class="font-medium">
                        <?php echo e($menu['label']); ?>

                    </span>

                    <span>+</span>
                </button>

                
                <div class="bg-white">

                    <?php $__currentLoopData = $menu['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <a
                            href="#"
                            class="block px-8 py-2 text-sm text-gray-700 hover:bg-gray-50 border-t"
                        >
                            <?php echo e($child); ?>

                        </a>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </nav>

</aside><?php /**PATH D:\carsmart_laravel\resources\views/components/sidebar.blade.php ENDPATH**/ ?>