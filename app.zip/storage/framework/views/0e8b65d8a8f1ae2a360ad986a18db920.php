

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="p-6">
        <h1 class="text-2xl font-bold">Dashboard</h1>
        <p class="text-gray-600 mt-2">
            Welcome to your system.
        </p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\carsmart_laravel\resources\views/dashboard.blade.php ENDPATH**/ ?>