@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
    <div class="p-6">
        <h1 class="text-2xl font-bold">Dashboard</h1>
        <p class="text-gray-600 mt-2">
            Welcome to your system.
        </p>
    </div>
@endsection