{{-- resources/views/layouts/app.blade.php --}}

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('app.name') }}</title>

    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="bg-gray-100">

    <div class="flex">

        {{-- Sidebar --}}
        <x-sidebar />

        {{-- Main Content --}}
        <main class="flex-1 ml-72 min-h-screen">

            {{-- Topbar --}}
            <header class="bg-white border-b px-6 py-4">
                <h1 class="text-xl font-semibold">
                    @yield('title')
                </h1>
            </header>

            {{-- Page Content --}}
            <div class="p-6">
                {{ $slot ?? '' }}

                @yield('content')
            </div>

        </main>

    </div>

</body>
</html>