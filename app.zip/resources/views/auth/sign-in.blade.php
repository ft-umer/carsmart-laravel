@extends('layouts.auth')

@section('title', 'Sign In')

@push('styles')
<style>
    .page-bg {
        background-image: url('{{ asset('assets/media/images/2600x1200/bg-10.png') }}');
    }
    .dark .page-bg {
        background-image: url('{{ asset('assets/media/images/2600x1200/bg-10-dark.png') }}');
    }
</style>
@endpush

@section('content')
<div class="flex items-center justify-center grow bg-center bg-no-repeat page-bg">
    <div class="kt-card max-w-[370px] w-full">

        <form
            action="{{ route('login') }}"
            method="POST"
            class="kt-card-content flex flex-col gap-5 p-10"
            id="sign_in_form"
        >
            @csrf

            {{-- ── Heading ── --}}
            <div class="text-center mb-2.5">
                <h3 class="text-lg font-medium text-mono leading-none mb-2.5">
                    Sign in
                </h3>
            </div>

            {{-- ── Error banner ── --}}
            @if ($errors->any() || session('error'))
                <div class="kt-alert kt-alert-danger flex items-center gap-2" role="alert">
                    <i class="ki-filled ki-shield-cross text-danger"></i>
                    <span class="text-sm">
                        {{ session('error') ?? 'We could not sign you in. Please check your details and try again.' }}
                    </span>
                </div>
            @endif

            {{-- ── Email ── --}}
            <div class="flex flex-col gap-1">
                <label for="email" class="kt-form-label font-normal text-mono">
                    Email address
                </label>
                <input
                    id="email"
                    name="email"
                    type="email"
                    class="kt-input @error('email') border-danger @enderror"
                    placeholder="email@email.com"
                    value="{{ old('email') }}"
                    required
                    autofocus
                    autocomplete="email"
                />
                @error('email')
                    <span class="text-xs text-danger mt-0.5">{{ $message }}</span>
                @enderror
            </div>

            {{-- ── Password ── --}}
            <div class="flex flex-col gap-1">
                <div class="flex items-center justify-between gap-1">
                    <label for="password" class="kt-form-label font-normal text-mono">
                        Password
                    </label>
                    <a href="{{ route('password.request') }}" class="text-sm kt-link shrink-0">
                        Forgot Password?
                    </a>
                </div>

                <div class="kt-input @error('password') border-danger @enderror"
                     data-kt-toggle-password="true">
                    <input
                        id="password"
                        name="password"
                        type="password"
                        placeholder="Enter Password"
                        required
                        autocomplete="current-password"
                    />
                    <button
                        class="kt-btn kt-btn-sm kt-btn-ghost kt-btn-icon bg-transparent! -me-1.5"
                        data-kt-toggle-password-trigger="true"
                        type="button"
                        aria-label="Toggle password visibility"
                    >
                        <span class="kt-toggle-password-active:hidden">
                            <i class="ki-filled ki-eye text-muted-foreground"></i>
                        </span>
                        <span class="hidden kt-toggle-password-active:block">
                            <i class="ki-filled ki-eye-slash text-muted-foreground"></i>
                        </span>
                    </button>
                </div>
                @error('password')
                    <span class="text-xs text-danger mt-0.5">{{ $message }}</span>
                @enderror
            </div>

            {{-- ── App choice ── --}}
            <div class="flex flex-col gap-1">
                <span class="kt-form-label font-normal text-mono">Application</span>
                <div class="flex items-center gap-4">
                    <label class="kt-label flex items-center gap-2 cursor-pointer">
                        <input
                            class="kt-radio kt-radio-sm"
                            type="radio"
                            name="app_target"
                            value="admin"
                            {{ old('app_target', session('last_app', 'admin')) === 'admin' ? 'checked' : '' }}
                        />
                        <span class="text-sm text-mono">Admin</span>
                    </label>
                    <label class="kt-label flex items-center gap-2 cursor-pointer">
                        <input
                            class="kt-radio kt-radio-sm"
                            type="radio"
                            name="app_target"
                            value="crm"
                            {{ old('app_target', session('last_app', 'admin')) === 'crm' ? 'checked' : '' }}
                        />
                        <span class="text-sm text-mono">Customer Relationship Management</span>
                    </label>
                </div>
            </div>

            {{-- ── Remember me ── --}}
            <label class="kt-label">
                <input
                    class="kt-checkbox kt-checkbox-sm"
                    type="checkbox"
                    name="remember"
                    value="1"
                    {{ old('remember') ? 'checked' : '' }}
                />
                <span class="kt-checkbox-label">Remember me</span>
            </label>

            {{-- ── Submit ── --}}
            <button type="submit" class="kt-btn kt-btn-primary flex justify-center grow">
                Sign In
            </button>

        </form>
    </div>
</div>
@endsection