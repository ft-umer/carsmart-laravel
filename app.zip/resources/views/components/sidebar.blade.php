{{-- =========================================================
B2. Left Navigation
Primary menus → Secondary menus → Pages
Fixed, collapsible sidebar with active state support
========================================================= --}}

@php
    $navigation = [
        [
            'label' => 'Dashboard',
            'children' => [
                'Overview',
                'Analytics',
                'Activity',
            ],
        ],

        [
            'label' => 'Leads',
            'children' => [
                'All Leads',
                'New Leads',
                'Qualified',
                'Archived',
            ],
        ],

        [
            'label' => 'Listings',
            'children' => [
                'All Listings',
                'Active Listings',
                'Drafts',
                'Categories',
            ],
        ],

        [
            'label' => 'Auctions',
            'children' => [
                'Live Auctions',
                'Upcoming',
                'Closed',
                'Bids',
            ],
        ],

        [
            'label' => 'Editions',
            'children' => [
                'All Editions',
                'Create Edition',
                'Schedules',
            ],
        ],

        [
            'label' => 'Vendors',
            'children' => [
                'Vendor Directory',
                'Applications',
                'Performance',
            ],
        ],

        [
            'label' => 'Customers',
            'children' => [
                'Customer List',
                'Segments',
                'Support Requests',
                'Purchase History',
            ],
        ],

        [
            'label' => 'Payments',
            'children' => [
                'Transactions',
                'Invoices',
                'Refunds',
                'Payouts',
            ],
        ],

        [
            'label' => 'Logistics',
            'children' => [
                'Shipments',
                'Tracking',
                'Warehouses',
                'Delivery Status',
            ],
        ],

        [
            'label' => 'Disputes',
            'children' => [
                'Open Cases',
                'Resolved',
                'Escalations',
            ],
        ],

        [
            'label' => 'Content Management',
            'children' => [
                'Pages',
                'Blogs',
                'Media Library',
                'SEO',
            ],
        ],

        [
            'label' => 'Automations',
            'children' => [
                'Workflows',
                'Email Automation',
                'Triggers',
                'Scheduled Tasks',
            ],
        ],

        [
            'label' => 'Reports',
            'children' => [
                'Sales Reports',
                'User Reports',
                'Auction Reports',
                'Exports',
            ],
        ],

        [
            'label' => 'Settings',
            'children' => [
                'General',
                'Users & Roles',
                'Integrations',
                'Security',
            ],
        ],

        [
            'label' => 'Notifications',
            'children' => [
                'Inbox',
                'Templates',
                'Preferences',
            ],
        ],

        [
            'label' => 'Tasks',
            'children' => [
                'My Tasks',
                'Team Tasks',
                'Completed',
            ],
        ],
    ];
@endphp

<aside class="w-72 h-screen fixed left-0 top-0 bg-white border-r overflow-y-auto">

    {{-- Header --}}
    <div class="p-5 border-b">
        <h2 class="text-xl font-bold">Admin Panel</h2>
    </div>

    {{-- Navigation --}}
    <nav class="p-4 space-y-2">

        @foreach ($navigation as $menu)

            <div class="border rounded-lg overflow-hidden">

                {{-- Primary Menu --}}
                <button
                    class="w-full flex items-center justify-between px-4 py-3 bg-gray-100 hover:bg-gray-200 transition"
                    type="button"
                >
                    <span class="font-medium">
                        {{ $menu['label'] }}
                    </span>

                    <span>+</span>
                </button>

                {{-- Secondary Menus / Pages --}}
                <div class="bg-white">

                    @foreach ($menu['children'] as $child)

                        <a
                            href="#"
                            class="block px-8 py-2 text-sm text-gray-700 hover:bg-gray-50 border-t"
                        >
                            {{ $child }}
                        </a>

                    @endforeach

                </div>

            </div>

        @endforeach

    </nav>

</aside>